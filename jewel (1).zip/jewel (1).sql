-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 10, 2024 at 05:08 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jewel`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminform`
--

CREATE TABLE `adminform` (
  `user_id` int(11) NOT NULL,
  `productname` varchar(200) NOT NULL,
  `price` int(200) NOT NULL,
  `discountprice` int(200) NOT NULL,
  `category` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `image` varchar(2000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `adminform`
--

INSERT INTO `adminform` (`user_id`, `productname`, `price`, `discountprice`, `category`, `type`, `image`) VALUES
(32, 'Platinum Ring', 43890, 1999, 'women Ring', 'ewplantinum', 'Uploads/r4.jpg'),
(33, 'Platinum Ring', 37980, 1499, 'women Ring', 'ewplantinum', 'Uploads/r5.jpg'),
(34, 'Platinum Ring', 36780, 1799, 'women Ring', 'ewplantinum', 'Uploads/r6.jpg'),
(35, 'Platinum Ring', 41000, 1999, 'women Ring', 'ewplantinum', 'Uploads/r7.jpg'),
(36, 'Platinum Ring', 45500, 1799, 'women Ring', 'ewplantinum', 'Uploads/r8.jpg'),
(37, 'Diamond Ring', 29870, 1399, 'women Ring', 'ewdiamond', 'Uploads/d10.jpg'),
(38, 'WhiteGold Ring', 32400, 1499, 'women Ring', 'ewwhitegold', 'Uploads/W1.jpg'),
(39, 'WhiteGold Ring', 27890, 1299, 'women Ring', 'ewwhitegold', 'Uploads/w2.jpg'),
(40, 'WhiteGold Ring', 31890, 999, 'women Ring', 'ewwhitegold', 'Uploads/w3.jpg'),
(41, 'WhiteGold Ring', 31000, 1399, 'women Ring', 'ewwhitegold', 'Uploads/w4.jpg'),
(42, 'WhiteGold Ring', 34500, 1999, 'women Ring', 'ewwhitegold', 'Uploads/w5.jpg'),
(43, 'WhiteGold Ring', 32000, 1799, 'women Ring', 'ewwhitegold', 'Uploads/w6.jpg'),
(46, 'WhiteGold Ring', 21000, 1299, 'women Ring', 'ewwhitegold', 'Uploads/w9.jpg'),
(47, 'WhiteGold Ring', 18900, 599, 'women Ring', 'ewwhitegold', 'Uploads/w10.jpg'),
(59, 'Platinum Ring', 32890, 1999, 'Men ring', 'mwplantinum', 'Uploads/pm.jpg'),
(60, 'Platinum Ring', 32900, 1599, 'Men ring', 'mwplantinum', 'Uploads/pm2.jpg'),
(61, 'Platinum Ring', 43560, 1999, 'Men ring', 'mwplantinum', 'Uploads/pm3.jpg'),
(62, 'Platinum Ring', 42890, 1899, 'Men ring', 'mwplantinum', 'Uploads/pm4.jpg'),
(63, 'Platinum Ring', 45390, 1999, 'Men ring', 'mwplantinum', 'Uploads/pm5.jpg'),
(64, 'Platinum Ring', 38790, 1299, 'Men ring', 'mwplantinum', 'Uploads/pm6.jpg'),
(65, 'Platinum Ring', 35780, 1399, 'Men ring', 'mwplantinum', 'Uploads/pm7.jpg'),
(66, 'Platinum Ring', 43890, 1399, 'Men ring', 'mwplantinum', 'Uploads/pm8.jpg'),
(67, 'WhiteGold Ring', 34690, 1499, 'Men ring', 'mwwhitegold', 'Uploads/wm1.jpg'),
(68, 'WhiteGold Ring', 27890, 1299, 'Men ring', 'mwwhitegold', 'Uploads/wm2.jpg'),
(69, 'WhiteGold Ring', 31890, 1199, 'Men ring', 'mwwhitegold', 'Uploads/wm3.jpg'),
(70, 'WhiteGold Ring', 43590, 1299, 'Men ring', 'mwwhitegold', 'Uploads/wm4.jpg'),
(71, 'WhiteGold Ring', 42780, 1499, 'Men ring', 'mwwhitegold', 'Uploads/wm6.jpg'),
(72, 'WhiteGold Ring', 36780, 1699, 'Men ring', 'mwwhitegold', 'Uploads/wm7.jpg'),
(73, 'WhiteGold Ring', 45900, 2999, 'Men ring', 'mwwhitegold', 'Uploads/wm8.jpg'),
(74, 'WhiteGold Ring', 36790, 1499, 'Men ring', 'mwwhitegold', 'Uploads/wm9.jpg'),
(76, 'Diamond Earing', 45670, 2999, 'Earing', 'jediamond', 'Uploads/e2.jpg'),
(77, 'Diamond Earing', 24590, 999, 'Earing', 'jediamond', 'Uploads/e3.jpg'),
(79, 'Diamond Earing', 43570, 1399, 'Earing', 'jediamond', 'Uploads/e5.jpg'),
(80, 'Diamond Earing', 43290, 2999, 'Earing', 'jediamond', 'Uploads/e7.jpg'),
(81, 'Diamond Earing', 45200, 3299, 'Earing', 'jediamond', 'Uploads/e8.jpg'),
(82, 'Diamond Earing', 43890, 2999, 'Earing', 'jediamond', 'Uploads/e10.jpg'),
(84, 'Diamond Earing', 38970, 2499, 'Earing', 'jediamond', 'Uploads/e9.jpg'),
(85, 'Diamond Earing', 42890, 2699, 'Earing', 'jediamond', 'Uploads/e6.png'),
(86, 'Pearl Earing', 32980, 1999, 'Earing', 'jepearl', 'Uploads/ep1.jpg'),
(87, 'Pearl Earing', 26890, 1299, 'Earing', 'jepearl', 'Uploads/ep2.jpg'),
(89, 'Pearl Earing', 31890, 1399, 'Earing', 'jepearl', 'Uploads/ep3.jpg'),
(90, 'Pearl Earing', 24560, 999, 'Earing', 'jepearl', 'Uploads/ep4.jpg'),
(91, 'Pearl Earing', 39900, 2599, 'Earing', 'jepearl', 'Uploads/ep5.jpg'),
(92, 'Pearl Earing', 42590, 3499, 'Earing', 'jepearl', 'Uploads/ep6.jpg'),
(93, 'Pearl Earing', 32670, 1299, 'Earing', 'jepearl', 'Uploads/ep7.jpg'),
(94, 'Pearl Earing', 43890, 2999, 'Earing', 'jepearl', 'Uploads/ep8.jpg'),
(95, 'Diamond Necklace', 123450, 4999, 'Necklace', 'jndiamond', 'Uploads/n1.jpg'),
(96, 'Diamond Necklace', 145670, 5999, 'Necklace', 'jndiamond', 'Uploads/n2.jpg'),
(97, 'Diamond Necklace', 204590, 7999, 'Necklace', 'jndiamond', 'Uploads/n3.jpg'),
(98, 'Diamond Necklace', 167890, 5999, 'Necklace', 'jndiamond', 'Uploads/n4.jpg'),
(99, 'Diamond Necklace', 98760, 3999, 'Necklace', 'jndiamond', 'Uploads/n5.jpg'),
(100, 'Diamond Necklace', 134790, 5999, 'Necklace', 'jndiamond', 'Uploads/n6.jpg'),
(101, 'Diamond Necklace', 136780, 4999, 'Necklace', 'jndiamond', 'Uploads/n7.jpg'),
(102, 'Diamond Necklace', 256780, 7999, 'Necklace', 'jndiamond', 'Uploads/n8.jpg'),
(103, 'Pearl Necklace', 123450, 3000, 'Necklace', 'jnpearl', 'Uploads/np1.jpg'),
(104, 'Pearl Necklace', 234560, 4000, 'Necklace', 'jnpearl', 'Uploads/np2.jpg'),
(105, 'Pearl Necklace', 234690, 4500, 'Necklace', 'jnpearl', 'Uploads/np3.jpg'),
(106, 'Pearl Necklace', 300260, 5000, 'Necklace', 'jnpearl', 'Uploads/np4.jpg'),
(107, 'Pearl Necklace', 150800, 5000, 'Necklace', 'jnpearl', 'Uploads/np5.jpg'),
(108, 'Pearl Necklace', 205090, 4500, 'Necklace', 'jnpearl', 'Uploads/np7.jpg'),
(109, 'Pearl Necklace', 300000, 50000, 'Necklace', 'jnpearl', 'Uploads/np8.jpg'),
(110, 'Pearl Necklace', 278900, 5000, 'Necklace', 'jnpearl', 'Uploads/np9.jpg'),
(111, 'Diamond Bracelets', 89790, 3000, 'bracelets', 'jbdiamond', 'Uploads/b1.jpg'),
(112, 'Diamond Bracelets', 110070, 5000, 'bracelets', 'jbdiamond', 'Uploads/b2.jpg'),
(113, 'Diamond Bracelets', 120790, 6000, 'bracelets', 'jbdiamond', 'Uploads/b3.jpg'),
(114, 'Diamond Bracelets', 90050, 4500, 'bracelets', 'jbdiamond', 'Uploads/b4.jpg'),
(115, 'Diamond Bracelets', 75000, 3500, 'bracelets', 'jbdiamond', 'Uploads/b5.jpg'),
(116, 'Diamond Bracelets', 105070, 6500, 'bracelets', 'jbdiamond', 'Uploads/b6.jpg'),
(117, 'Diamond Bracelets', 90800, 4000, 'bracelets', 'jbdiamond', 'Uploads/b7.jpg'),
(118, 'Diamond Bracelets', 120700, 7000, 'bracelets', 'jbdiamond', 'Uploads/b8.jpg'),
(119, 'Pearl Bracelets', 200000, 5000, 'bracelets', 'jbpearl', 'Uploads/bp1.jpg'),
(120, 'Pearl Bracelets', 350000, 7000, 'bracelets', 'jbpearl', 'Uploads/bp2.jpg'),
(121, 'Pearl Bracelets', 240500, 6500, 'bracelets', 'jbpearl', 'Uploads/bp3.jpg'),
(122, 'Pearl Bracelets', 180700, 4000, 'bracelets', 'jbpearl', 'Uploads/bp4.jpg'),
(123, 'Pearl Bracelets', 250700, 5000, 'bracelets', 'jbpearl', 'Uploads/bp4.jpg'),
(124, 'Pearl Bracelets', 208060, 5000, 'bracelets', 'jbpearl', 'Uploads/bp5.jpg'),
(125, 'Pearl Bracelets', 300600, 6700, 'bracelets', 'jbpearl', 'Uploads/bp7.jpg'),
(126, 'Pearl Bracelets', 270600, 4000, 'bracelets', 'jbpearl', 'Uploads/bp8.jpg'),
(127, 'Pearl Bracelets', 300890, 4000, 'bracelets', 'jbpearl', 'Uploads/bp10.jpg'),
(128, 'Pearl Bracelets', 150000, 2000, 'bracelets', 'jbpearl', 'Uploads/bp1.jpg'),
(129, 'Pearl Bracelets', 180000, 2500, 'bracelets', 'jbpearl', 'Uploads/bp2.jpg'),
(130, 'Pearl Bracelets', 90000, 500, 'bracelets', 'jbpearl', 'Uploads/bp3.jpg'),
(131, 'Pearl Bracelets', 120000, 2300, 'bracelets', 'jbpearl', 'Uploads/bp4.jpg'),
(133, 'Pearl Bracelets', 150000, 2000, 'bracelets', 'jbpearl', 'Uploads/bp7.jpg'),
(134, 'Pearl Bracelets', 130000, 2100, 'bracelets', 'jbpearl', 'Uploads/bp8.jpg'),
(135, 'Pearl Bracelets', 160000, 2800, 'bracelets', 'jbpearl', 'Uploads/bp10.jpg'),
(136, 'Pearl Bracelets', 170000, 2500, 'bracelets', 'jbpearl', 'Uploads/55f4e3d09dd7cc1e008b9f55-750-563.jpg'),
(138, 'fghjfg', 656, 55, 'women Ring', 'ewdiamond', 'Uploads/1560486882120575d0323e23045255f4e3d09dd7cc1e008b9f55-750-563.jpg'),
(139, 'Diamond Bangles', 58526, 442, 'bangles', 'jbndiamond', 'Uploads/gud30.jpg'),
(140, 'Diamond Bangles', 985423, 2356, 'bangles', 'jbndiamond', 'Uploads/w10.jpg'),
(141, 'Diamond Bangles', 45545, 788, 'bangles', 'jbndiamond', 'Uploads/d2.jpg'),
(142, 'Diamond Bracelets', 58855, 788, 'bangles', 'jbndiamond', 'Uploads/d3.jpg'),
(143, 'Pearl Bangles', 88556, 255, 'bangles', 'jbnpearl', 'Uploads/bp4.jpg'),
(144, 'Pearl Bangles', 78552, 45, 'bangles', 'jbnpearl', 'Uploads/bp7.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `adminregister`
--

CREATE TABLE `adminregister` (
  `id` int(11) NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `adminregister`
--

INSERT INTO `adminregister` (`id`, `username`, `password`) VALUES
(1, 'ranga', '111');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `image_url` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `image_url`) VALUES
(8, 'IMG-5f8954bd209a92.78214246.jpg'),
(9, 'IMG-5f8954caa02539.76436861.jpg'),
(10, 'IMG-660be34ecdd651.49511760.png'),
(11, 'IMG-660bef27337aa3.38037672.png'),
(12, 'IMG-660bff3a2a8b65.99215766.png'),
(13, 'IMG-660bff77c754f8.22147977.png'),
(14, 'IMG-660bfffe6456a2.92699729.png'),
(15, 'IMG-660c00db4bbdc2.75050740.png');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `order_id` int(11) NOT NULL,
  `reg_id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `productname` varchar(100) NOT NULL,
  `price` int(100) NOT NULL,
  `discountprice` int(100) NOT NULL,
  `Total` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `payment` varchar(100) NOT NULL,
  `cardno` varchar(100) NOT NULL,
  `pin` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`order_id`, `reg_id`, `user_id`, `productname`, `price`, `discountprice`, `Total`, `name`, `phone`, `address`, `email`, `payment`, `cardno`, `pin`) VALUES
(1, 4, 3, 'km', 0, 0, '521', 'sedfjkh', '435210', 'srdtfyuhl', 'acharyashruthi1@gmail.com', 'cashondelivery', '', ''),
(2, 4, 4, 'hgb', 0, 0, '6469', 'gh', '8652', 'seterytjghjk', 'Shravyaacharya123@gmail.com', 'cashondelivery', '', ''),
(3, 3, 20, 'Diamond Ring', 28900, 1999, '26901', 'Ranganayaki', '6523652', 'jshyghx gdsHb cdsghb', 'Ranganayaki@gmail.com', 'cashondelivery', '', ''),
(4, 3, 20, 'Diamond Ring', 28900, 1999, '26901', 'Ranganayaki', '6523652', 'jshyghx gdsHb cdsghb', 'Ranganayaki@gmail.com', 'cashondelivery', '', ''),
(5, 3, 3, 'hgb', 0, 0, '6469', 'shruthi', '5263', 'ggf gh racd ggk', 'supritha@gmail.com', 'debitcard', '254545245', '202020'),
(6, 3, 3, 'hgb', 0, 0, '6469', 'shruthi', '5263', 'ggf gh racd ggk', 'supritha@gmail.com', 'debitcard', '254545245', '202020'),
(7, 3, 3, 'hgb', 0, 0, '6469', 'shruthi', '5263', 'ggf gh racd ggk', 'supritha@gmail.com', 'debitcard', '254545245', '202020'),
(8, 4, 6, 'Diamond Necklace', 0, 0, '118451', 'shruthi', '5566', 'gh nhxb hjn\r\n', 'supritha@gmail.com', 'cashondelivery', '', '576321'),
(9, 5, 98, 'Diamond Necklace', 167890, 5999, '161891', 'Shravya', '9858741235', '11th cross nejar ,udupi.', 'Shravyaacharya123@gmail.com', 'cashondelivery', '', '576321'),
(10, 5, 60, 'Platinum Ring', 32900, 1599, '31301', 'supritha', '9632145287', 'hasana,karnataka', 'supritha@gmail.com', 'cashondelivery', '', ''),
(11, 5, 77, 'Diamond Earing', 24590, 999, '23591', 'Ranganayaki', '96321547852', 'Rangaathittu', 'Ranganayaki@gmail.com', 'creditcard', '', ''),
(12, 5, 11, 'Pearl Necklace', 0, 0, '230560', 'Ranga', '9854213578', 'chamarajaagara ,bangalore', 'soujnyaacharya999@gmail.com', 'cashondelivery', '', '576328'),
(13, 5, 60, 'Platinum Ring', 32900, 1599, '31301', 'gv', '52125', 'sdf sgdhg', 'supritha@gmail.com', 'cashondelivery', '', ''),
(14, 5, 118, 'Diamond Bracelets', 120700, 7000, '113700', 'Shravya', '9947854215', 'Dockter helllo ji mok docs man', 'shrupritha@gmail.com', 'cashondelivery', '', ''),
(15, 5, 79, 'Diamond Earing', 43570, 1399, '42171', 'preethi maam', '98652476', 'mukka mangalore', 'Ranganayaki@gmail.com', 'cashondelivery', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `reg_id` int(11) NOT NULL,
  `user_name` varchar(225) NOT NULL,
  `user_email` varchar(225) NOT NULL,
  `user_phone` varchar(100) NOT NULL,
  `user_address` varchar(250) NOT NULL,
  `user_password` varchar(100) NOT NULL,
  `user_secret` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`reg_id`, `user_name`, `user_email`, `user_phone`, `user_address`, `user_password`, `user_secret`) VALUES
(5, 'Ranganayaki', 'Ranganayaki@gmail.com', '8722048585', 'Ranganayaki hasana Karnataka', '123', ''),
(6, 'shruthi', 'soujnyaacharya999@gmail.com', '522', 'nejar muduthonse', '147', ''),
(8, 'Surpanaka', 'Surpanaka@gmail.com', '9856321457', 'Lingappa \"maruthi\" nilaya madikeri', '456', 'poo'),
(9, 'raksha', 'rakshanayak@gmail.com', '8722042824', 'udupi,karnataka                                \r\n                            ', '123456', 'smvitm');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `rev` int(100) NOT NULL,
  `reg_id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `review` varchar(100) NOT NULL,
  `rating` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`rev`, `reg_id`, `user_id`, `review`, `rating`) VALUES
(1, 3, 7, 'tooo bad', '1'),
(2, 3, 20, 'this product is too good', '5'),
(3, 4, 20, 'Dimtananana', '3'),
(4, 4, 29, 'hello iam shra', '1'),
(5, 5, 96, 'So beautifull..got as expcted', '5'),
(6, 5, 20, 'Nice design,liked it very much', '5'),
(7, 5, 77, 'Not so good', '4'),
(8, 8, 20, 'Not as expected', '2');

-- --------------------------------------------------------

--
-- Table structure for table `shopping_cart`
--

CREATE TABLE `shopping_cart` (
  `CartId` int(100) NOT NULL,
  `reg_id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `ItemName` varchar(100) NOT NULL,
  `Quantity` int(100) NOT NULL,
  `Price` int(100) NOT NULL,
  `Total` varchar(100) NOT NULL,
  `OrderDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `shopping_cart`
--

INSERT INTO `shopping_cart` (`CartId`, `reg_id`, `user_id`, `ItemName`, `Quantity`, `Price`, `Total`, `OrderDate`) VALUES
(1, 0, 1, 'Ring', 1, 100, '80', '2019-01-19'),
(2, 0, 2, 'a', 1, 400, '355', '2019-01-19'),
(5, 3, 20, 'Diamond Ring', 1, 28900, '26901', '2019-01-23'),
(7, 4, 61, 'Platinum Ring', 1, 43560, '41561', '2019-01-25'),
(8, 4, 40, 'WhiteGold Ring', 2, 31890, '61782', '2019-01-25'),
(9, 5, 29, 'Platinum Ring', 1, 35000, '33301', '2019-01-29'),
(10, 5, 97, 'Diamond Necklace', 1, 204590, '196591', '2019-01-29'),
(13, 5, 60, 'Platinum Ring', 1, 32900, '31301', '2019-05-08');

-- --------------------------------------------------------

--
-- Table structure for table `studentusn`
--

CREATE TABLE `studentusn` (
  `usn` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `studentusn`
--

INSERT INTO `studentusn` (`usn`) VALUES
('088'),
('065'),
('099'),
('077'),
('100'),
('055');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminform`
--
ALTER TABLE `adminform`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `adminregister`
--
ALTER TABLE `adminregister`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`reg_id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`rev`);

--
-- Indexes for table `shopping_cart`
--
ALTER TABLE `shopping_cart`
  ADD PRIMARY KEY (`CartId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adminform`
--
ALTER TABLE `adminform`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=147;

--
-- AUTO_INCREMENT for table `adminregister`
--
ALTER TABLE `adminregister`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `reg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `rev` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `shopping_cart`
--
ALTER TABLE `shopping_cart`
  MODIFY `CartId` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
