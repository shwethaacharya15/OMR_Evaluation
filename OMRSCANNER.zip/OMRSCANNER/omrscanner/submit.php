 <?php
if(isset($_POST['submit']))
{
include("connection.php");
include("session.php");

$user_id=$_POST['user_id'];
$review=$_POST['review'];
$rating=$_POST['rating'];
$query=mysqli_query($con,"INSERT INTO `reviews`(`rev`,`reg_id`, `user_id`, `review`, `rating`) VALUES ('','$reg_id','$user_id','$review','$rating')") or die(mysqli_error($con));
if($query)
{
	header("location:v2.php?success");
}
else
{
	header("location:v2.php?error");
}
}
?>