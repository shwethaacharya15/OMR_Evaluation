
<?php
include("session.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">


    
    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.css" rel="stylesheet">
    <link href="css/style3.css" rel="stylesheet">

    <title>Marks Table</title>




    <meta charset="utf-8">
        <meta name="viewport" content="initial-scale=1.0, maximum-scale=1.0, user-scalable=1">
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.4/css/jquery.dataTables.min.css">
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/2.2.2/css/buttons.dataTables.min.css">
        <link rel="stylesheet" type="text/css" href="css/style.css">

        <style>

*, *:after,*:before{
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    -ms-box-sizing: border-box;
    box-sizing: border-box;
}
body{
    font-family: arial;
    font-size: 16px;
    margin: 0;
    background: #fff;
    color: #000;
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 120vh;
    
}

.container{
    max-width: 1100px;
    width: 100%;
}

.navbar-default {
    position: fixed;
    top: 0;
    width: 100%;
    height: 60px;
    background-color: #f8f8f8;
    z-index: 1000;
    border: none;
}

.navbar-default .container {
    padding-right: 15px;
    padding-left: 15px;
    margin-right: auto;
    margin-left: auto;
    width: 100%;
}

.navbar-default .navbar-header {
    float: none;
}

.navbar-default .navbar-toggle {
    display: none;
}

.navbar-default .btn {
    margin-left: 5px;
    margin-top: 1px;
    float: right;
}

.navbar-default .btn.btn-lg {
    margin-top: 1px;
    float: right;
}

.navbar-default .btn.btn-danger {
    margin-top: 1px;
    float: right;
}


       </style>



</head>

<body>


    <nav class="navbar-default">
        <a href="#"><img src="images/bluemoon.png" class="img-responsive logo" style="width:150px; float:left;"
                alt="Blue Nile&reg;" title="Blue Nile&reg;" /></a>

        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>

            <a href="v2.php"><button type="button" class="btn btn-lg" style="float: right;">BACK</button></a>
            <a href="delete1.php"><button type="button" class="btn btn-lg" style="float: right;  ">DELETE ALL </button></a>
        </div>
    </nav>



<div class="container">
    <table id="example" class="display nowrap" style="width:100%">
       <thead>
         <tr>
            <th>SL.NO</th>
            <th>USN</th>
   
            <th>SCORE</th>
            
          
        </tr>
        </thead>



        <tbody>    
        <?php
include("connection.php");

$query = mysqli_query($con, "SELECT studentusn.usn, marks.value
                             FROM studentusn
                             INNER JOIN marks ON studentusn.id = marks.id
                             ORDER BY studentusn.usn ASC") 
         or die(mysqli_error($con));

$i = 1;
while ($row = mysqli_fetch_array($query)) {
    echo '
        <tr class="bor_1">
            <td class="bor">' . $i++ . '</td>
            <td class="bor">' . $row['usn'] . '</td>
            <td class="bor">' . $row['value'] . '</td>
        </tr>
    ';
}
?>


         </tbody>
    </table>
    </div>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.11.4/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.2/js/dataTables.buttons.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.html5.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.print.min.js"></script>



        <script>
        $(document).ready(function() {
            $('#example').DataTable( {
                dom: 'Bfrtip', 
                buttons: [
                        'copy', 'csv', 'excel', 'pdf', 'print'
                    ]
            } );
        } );
    </script>


</body>

</html>



