<?php
// Assuming you already have a MySQL connection established
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "jewel";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the USN from the form submission
$usn = $_POST['usn'];

// Insert the USN into the studentusn table
$sql = "INSERT INTO studentusn (usn) VALUES ('$usn')";

if ($conn->query($sql) === TRUE) {
    // Redirect to index1.php
    header("location: index1.php");
    exit(); // Stop further execution
} else {
    echo "Error inserting record: " . $conn->error;
}

// Close connection
$conn->close();
?>
