<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
     <link href="css/font-awesome.css" rel="stylesheet">
      <link href="css/style.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>
    <a href="#"><img src="bluemoon.png"  class="img-responsive" class="logo" style="width:350px; height:150px ";
                     alt="Blue Nile&reg;"     title="Blue Nile&reg;"  >
            </a>
        
        <nav class="navbar navbar-light" style="background-color: #e3f2fd>
            <div class="navbar-header">
            </div>
            
            <ul class="nav navbar-nav navbar-left">
                <li><div style="padding-right:10px">
                    <h3 class="btn "  ><a href="home.php">Home</a>
                    <span ></span></h3>
                </div></li>
                
            </ul>
        </nav>

    <!-- Navigation -->
      
   
       
        <div class="container">
            <header >
        <h3 class="about_us3">Update Products</h3>
    </header>
            <div class="row">
               <div class="col-md-12 adjust1">
                <div class="well">
                    
                    <hr>
                    <?php 
                        if(isset($_GET['user_id']))
                        {   include("connection.php");
                            $user_id=$_GET['user_id'];
                            $query=mysqli_query($con,"SELECT * FROM `adminform` WHERE user_id='$user_id'") or die(mysqli_error($con));
                            $row=mysqli_fetch_array($query);
                        }
                    ?>
 
 <form name="update_form" method="POST" action="u_reg_vals.php?user_id=<?php echo $row['user_id']; ?>&&update" enctype="multipart/form-data"> 
      <div class="form-group">
        <label> Name  </label>
        <input type="text" class="form-control" name="productname" placeholder="enter your name" value="<?php echo $row['productname']; ?>" required="">
    </div>
    <div class="form-group">
        <label> price </label>
        <input type="number" class="form-control" name="price" placeholder="enter your email" value="<?php echo $row['price']; ?>" required="">
    </div>
    <div class="form-group">
        <label> Discount price  </label>
        <input type="number" class="form-control" name="discountprice" placeholder="enter your number" value="<?php echo $row['discountprice']; ?>" >
    </div>
   
    
     
    <div>
                       <label>Category </label>
                            <select name="category" required>
                                <option>women Ring</option>
                                <option>Men ring</option>
                                <option> Earing</option>
                                <option>Necklace</option>
                                <option>bracelets</option>
								<option>bangles</option>
                            </select>  
                    </div>
    <div>
                        <label>Type </label>
                            <select name="type" required>
                                <option>ewdiamond</option>
                                <option>ewplantinum</option>
                                <option>ewwhitegold</option>
								<option>mwdiamond</option>
                                <option>mwplantinum</option>
                                <option>mwwhitegold</option>
                                <option>jediamond</option>
                                <option>jepearl</option>
								<option>jndiamond</option>
                                <option>jnpearl</option>
								<option>jbdiamond</option>
                                <option>jbpearl</option>
								<option>jbndiamond</option>
                                <option>jbnpearl</option>
                            </select>   
                    </div>
    
    <div class="form-group">
        <label>Image</label>
        <input type="file" name="image" value="<?php echo $row['image']; ?>"  required="">
        
    </div>
   
   

    
    <div class="form-group">
        <input type="submit"  class="btn btn-primary btn-block" name="update_btn" value="Update" >
    </div>
  </form>

</div>


                </div>
              
                </div>

                
            </div>
        


        <!-- /.container -->
    
</div>

    <!-- Page Content -->
   


    <!-- jQuery Version 1.11.1 -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
