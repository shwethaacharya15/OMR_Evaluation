<?php
	session_start();
	$reg_id = $_SESSION['reg_id'];
	?>