<?php
if(isset($_POST['register']))
{
include("connection.php");
$name=$_POST['name'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$address=$_POST['address'];
$password=$_POST['password'];
$secret=$_POST['secret'];

$query=mysqli_query($con,"INSERT INTO `register`(`reg_id`, `user_name`, `user_email`,`user_phone`,`user_address`, `user_password`,`user_secret` ) VALUES ('','$name','$email','$phone','$address','$password','$secret')") or die(mysqli_error($con));
if($query)
{
	header("location:v2login.php?success");
}
else
{
	header("location:v2signin.php?error");
}
}

?>