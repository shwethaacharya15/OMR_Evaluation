<!DOCTYPE html>
<html>
<head>
	

	<title>OMR</title> 
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
 <script src="css/jquery-1.11.1.min.js"></script>
  
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  
 <style>
* {
    box-sizing: border-box;
}

.column {
    float: left;
    width: 50%;
    padding: 30px;
    height: 350px;
}

.row:after {
    content: "";
    display: table;
    clear: both;
}

@media screen and (max-width: 600px) {
    .column {
        width: 100%;
    }
}

.column1 {
    float: left;
    width: 50%;
    padding: 7px;
}
@media screen and (max-width: 600px) {
    .column1 {
        width: 100;
    }
}


.column2 {
    float: left;
    width: 33.33%;
    padding: 3px;
}
@media screen and (max-width: 600px) {
    .column2 {
        width: 100%;
    }
}

.column3 {
    float: left;
    width: 33.33%;
    padding: 30px;
    height: 250px; 
}
@media screen and (max-width: 600px) {
    .column3 {
        width: 100%;
    }
}


.vl {
    border-left: 1px solid ;
    height: 20px;
}
</style>
  



<style>


.tiny-footer { font-size: 14px; padding: 14px 0px; font-weight: 600; background-color: transparent; border-top: 1px solid #152e3d; color: #888d90; line-height: 1; }


</style>



  
 
<script type="text/javascript">
	$(document).ready(function(){

$('#myCarousel').carousel({ interval: 2000 });

$('.multi-item-carousel .item').each(function(){
var itemToClone = $(this);

for (var i=1;i<4;i++) {
itemToClone = itemToClone.next();

if (!itemToClone.length) {
itemToClone = $(this).siblings(':first');
}

itemToClone.children(':first-child').clone()
.addClass("cloneditem-"+(i))
.appendTo($(this));
}
});
});

</script>
  


	<style>
		.myomr {
			background-image :url("images/omr1.png");
			background-repeat: no-repeat;
			background-size: 100%;
			display: flex;
			justify-content: center;
			align-items: center;
			flex-direction: column;
			min-height: 100vh;
		}
	</style>








</head>
<body>


<nav class="navbar-default"  >
<a href="#"><img src="images/bluemoon.png"  class="img-responsive" class="logo" style="width:150px; float:left;  "
                     alt="Blue Nile&reg;"     title="Blue Nile&reg;"  />
				</a>
        
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
                 
      </button>

    </div>


	  
      <a href="v2.php"><button type="button" class="btn btn-lg" style="float: right;" >Back</button></a>


	

	
  </div>
  
</nav>


<div class="myomr">


<!-- <form  action="upload1.php" method="post">
        <label for="">USN</label>
        <input type="text" name="name"   placeholder="Last 3 Digits">
        <input type="submit" 
                  name="name"
                  class="btn btn-lg"
                  style="color: #4062be;"
                  value="OK">
    </form>
 -->




    <!-- <form action="upload1.php" method="post">
    <label for="name"><b>Name</b></label>
    <input type="text" placeholder="Enter Name" name="name" required>
    <button type="submit" class="registerbtn" name="submit1" value="Register">OK</button>
    </form>  -->

    <h3>Upload The Correct Answer Sheet Here</h3>


	<?php if (isset($_GET['error'])): ?>
		<p><?php echo $_GET['error']; ?></p>
	<?php endif ?>




     <form action="upload2.php"
     class="btn btn-lg"
     
           method="post"
           enctype="multipart/form-data">




           <input type="file" 
           class="btn btn-lg"
           style="background:  #818caa;"
                  name="mymy_image">

           <input type="submit" 
                  name="submit"
                  class="btn btn-lg"
                  style="color: #4062be;"
                  value="UPLOAD">


     	
     </form>
	</div>
</body>
</html>