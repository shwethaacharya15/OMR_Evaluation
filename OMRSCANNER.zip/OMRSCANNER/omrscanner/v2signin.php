<!DOCTYPE html>
<html>
<head><title>omr</title> 
<meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="G:/BS/css/bootstrap.min.css">
<style>
body {
    font-family: Arial, Helvetica, sans-serif;
}

* {
    box-sizing: border-box;
}








/* Add padding to containers */
.container {

 width:800px;
 position:relative;
left:300px;
top:100px;

  border-radius: 5px;
 padding: 50px;
 padding-top:0px;   /*padding: 50px;*/
    background-color: silver;
	
}

/* Full-width input fields */
input[type=text], input[type=password] {
    width: 100%;
    padding: 15px;
    margin: 5px 0 22px 0;
    display: inline-block;
    border: none;
    background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
    background-color: #ddd;
    outline: none;
}

/* Overwrite default styles of hr */
hr {
    border: 1px solid #f1f1f1;
    margin-bottom: 25px;
}

/* Set a style for the submit button */
.registerbtn {
    background-color: #4CAF50;
    color: white;
    padding: 16px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
    opacity: 0.9;
}

.registerbtn:hover {
    opacity: 1;
}

/* Add a blue text color to links */
a {
    color: dodgerblue;
	color:blue;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
    background-color: #f1f1f1;
	height:60px;
	width:800px;
	background-color: silver;
    text-align: center;
	position:relative;
left:300px;
top:50px;
padding-top:10px;}
</style>
</head>
<body style="background-color:#f2f2f2">
<div>
<a href="#"><img src="images/bluemoon.png"  class="img-responsive" class="logo" style="width:280px; float:left; "
                     alt="Blue Nile&reg;"     title="Blue Nile&reg;"  />
				</a>
        </div>
<!--form action="/action_page.php"-->

  <div class="container">
   <form action="signup.php" method="post">
    <h1 style="font-family:jokerman; font-size:45px;color:navy">Register</h1>
    <p style="padding-right:5px;">Please fill in this form to create an account.</p>
    <hr>

    <label for="name"><b>Name</b></label>
    <input type="text" placeholder="Enter Name" name="name" required>

    <label for="email"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="email" required>

    <label for="phone"><b>Phone</b></label>
    <input type="text" placeholder="Enter Phone Number" name="phone" required>
    <label for="address"><b>Address</b></label>
    <input type="text" placeholder="Enter Address" name="address" required>

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="password" required>



  <label for="psw"><b> Enter secret word</b></label>
 <input type="password" class="form-control" name="secret"  placeholder="This will help if your forget your password" required="">
                     


    <!--label for="psw-repeat"><b>Repeat Password</b></label>
    <input type="password" placeholder="Repeat Password" name="psw-repeat" required-->





    <button type="submit" class="registerbtn" name="register" value="Register">Register</button>
  </div>

  </form> 
   

  
  <div class="signin">
    <p>Already have an account? <a href="v2login.php">Sign in</a>.</p>
  </div>
<!--/form-->

</body>
</html>
