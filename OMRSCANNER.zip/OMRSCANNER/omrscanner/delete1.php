<?php
include("connection.php");

// Truncate the marks table
$query_marks = mysqli_query($con, "TRUNCATE TABLE `marks`") or die(mysqli_error($con));

// Truncate the studentusn table
$query_studentusn = mysqli_query($con, "TRUNCATE TABLE `studentusn`") or die(mysqli_error($con));

if ($query_marks && $query_studentusn) {
    header("location:score.php?deleted");
} else {
    header("location:score.php?error");
}
?>
