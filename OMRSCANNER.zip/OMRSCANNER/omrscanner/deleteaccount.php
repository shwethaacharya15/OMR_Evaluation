<!DOCTYPE html>
<html>
<head>
	<title>delete account</title>
	 <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

   

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
     <link href="css/font-awesome.css" rel="stylesheet">
      <link href="css/style1.css" rel="stylesheet">

</head>

 
<body style="background-color:#f2f2f2">
   



<nav class="navbar-default"  >
<a href="#"><img src="images/bluemoon.png"  class="img-responsive" class="logo" style="width:150px; float:left;  "
                     alt="Blue Nile&reg;"     title="Blue Nile&reg;"  />
				</a>
        
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
                 
      </button>

    </div>


	  
      <a href="v2.php"><button type="button" class="btn btn-lg" style="float: right;" >Back</button></a>


	

	
  </div>
  
</nav>







  <div class="row">
    <nav class="navbar navbar-default  nav1" role="navigation">
           <div class="container">        
         <div class="navbar-header">
                         
                          <a class="navbar-brand"  style="font-family:jokerman;color:blue;font-size:35px;text-align: center">Delete Account</a>
                      </div>
                  </div>
              </nav>
          </div>
          <div class="row">
            <div class="col-md-2"></div>
                <div class="col-md-8">
                    <div class="well">
                    <form name="delete name" method="POST" action="">
                        <label>ARE YOU SURE YOU WANT TO DELETE YOUR ACCOUNT</label>
                         <div class="form-group">
                            <input type="submit" class="btn btn-success btn-lg" name="yes" value="Yes">
                            <a href="v2.php"><button type="button" class="btn btn-danger btn-lg">NO</button></a>
                            
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-2"></div>
            <?php
            if(isset($_POST['yes']))
            {
                include("connection.php");
                include("session.php");
                
                 $sql1=mysqli_query($con,"DELETE FROM `register` WHERE reg_id='$reg_id'") or die(mysqli_error($con));
               
             if($sql1)
                  {
                header("location:index.php?success");
                   }
               }
                ?>

               
            
<script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

      </body>