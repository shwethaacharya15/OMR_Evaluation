<?php

if (isset($_POST['submit']) && isset($_FILES['mymy_image'])) {
    include "connection.php";

    $img_name = $_FILES['mymy_image']['name'];
    $img_size = $_FILES['mymy_image']['size'];
    $tmp_name = $_FILES['mymy_image']['tmp_name'];
    $error = $_FILES['mymy_image']['error'];

    if ($error === 0) {
        if ($img_size > 5000000) {
            $em = "Sorry, your file is too large.";
            header("Location: index2.php?error=$em");
        } else {
            $new_img_name = "teacherimage.jpg"; // Set a standard name
            $img_upload_path = 'teacheruploads/'.$new_img_name;
            move_uploaded_file($tmp_name, $img_upload_path);

            // Insert into Database
            $sql = "INSERT INTO teacherimages(image)
                    VALUES('$new_img_name')";
            mysqli_query($con, $sql);

            
            header("Location: index2.php");
        }
    } else {
        $em = "Unknown error occurred!";
        header("Location: index2.php?error=$em");
    }

} else {
    header("Location: index2.php");
}
?>