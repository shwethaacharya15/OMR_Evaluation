
<?php
if(isset($_POST['submit1']))
{
include("connection.php");
$name=$_POST['name'];


$query=mysqli_query($con,"INSERT INTO `studentusn`(`usn`) VALUES ('$name')") ;
if($query)
{
	header("location:index1.php?success");
}
else
{
	header("location:index1.php?error");
}
}

?>