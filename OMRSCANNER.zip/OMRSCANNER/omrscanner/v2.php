<!DOCTYPE html>
<html>
<head>
  

<title>OMR</title> 

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <!--link rel="stylesheet" href="E:/BS/css1/bootstrap.css"-->
  <!--link rel="stylesheet" href="E:/BS/css1/bootstrap-theme.min"-->
 <script src="css/jquery-1.11.1.min.js"></script>
  
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  
 <style>
* {
    box-sizing: border-box;
}

/* Create two equal columns that floats next to each other */
.column {
    float: left;
    width: 50%;
    padding: 30px;
    height: 350px; /* Should be removed. Only for demonstration */
}

/* Clear floats after the columns */
.row:after {
    content: "";
    display: table;
    clear: both;
}

/* Responsive layout - makes the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
    .column {
        width: 100%;
    }
}

.column1 {
    float: left;
    width: 50%;
    padding: 7px;
}
@media screen and (max-width: 600px) {
    .column1 {
        width: 100;
    }
}


.column2 {
    float: left;
    width: 33.33%;
    padding: 3px;
}
@media screen and (max-width: 600px) {
    .column2 {
        width: 100%;
    }
}

.column3 {
    float: left;
    width: 33.33%;
    padding: 30px;
    height: 250px; /* Should be removed. Only for demonstration */
}
@media screen and (max-width: 600px) {
    .column3 {
        width: 100%;
    }
}


.vl {
    border-left: 1px solid ;
    height: 20px;
}
</style>
  



<style>


.tiny-footer { font-size: 14px; padding: 14px 0px; font-weight: 600; background-color: transparent; border-top: 1px solid #152e3d; color: #888d90; line-height: 1; }


</style>








  
 
<script type="text/javascript">
	$(document).ready(function(){

$('#myCarousel').carousel({ interval: 2000 });

$('.multi-item-carousel .item').each(function(){
var itemToClone = $(this);

for (var i=1;i<4;i++) {
itemToClone = itemToClone.next();

if (!itemToClone.length) {
itemToClone = $(this).siblings(':first');
}

itemToClone.children(':first-child').clone()
.addClass("cloneditem-"+(i))
.appendTo($(this));
}
});
});

</script>
  

  
</head>


<body style="background-color:#f2f2f2;">



<nav class="navbar-default"  >
<a href="#"><img src="images/bluemoon.png"  class="img-responsive" class="logo" style="width:150px; float:left;  "
                     alt="Blue Nile&reg;"     title="Blue Nile&reg;"  />
				</a>
        
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
                 
      </button>

    </div>
	
	
	
	
	
	
	
	
            <!--a href="#"><img src="E:/BS/pro.jpg"  class="img-responsive" class="logo" style="width:100px; float:left;  "
                     alt="Blue Nile&reg;"     title="Blue Nile&reg;"  />
				</a-->
        
	
	
	
	
	
	
	
	
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        
        
		
		
    
	
	  
	  
	  <li><div class="dropdown" style=" position:relative; top:-13px; ">
    <h3 class="btn  dropdown-toggle" type="button" data-toggle="dropdown" style="font-size:15px;">My Profile
    <span class="caret"></span></h3>
    <ul class="dropdown-menu">
	
      
	  
      <!-- <li><a href="manage.php">Manage Account</a></li> -->
	   <li><a href="deleteaccount.php">Delete Account</a></li>
      <li><a href="logout.php">Log Out</a></li>
	

    </ul>
  </div>

		</li>
	  
	  
	  
	  
	  
	  
		
		
      </ul>
    </div>
	
  </div>
  
</nav>




<div style="clear:both;"></div>

	

<nav class="navbar-default"   >
  <div class="container" >
   
    <div class="collapse navbar-collapse" id="myNavbar" >
      <ul class="nav navbar-nav navbar-left">
        
        
		
		<li><div class="dropdown"style="padding-right:200px">
    <!-- <h3 class="btn  dropdown-toggle" type="button" data-toggle="dropdown" style="font-size:19px;">   
    <span class="caret"></span></h3> -->
    
    <ul class="dropdown-menu">
	<li class="dropdown-header">Women's ring</li>
      
	  
      <li><a href="wdiamond.php">Diamond</a></li>
      <li><a href="wplatinum.php">Platinum</a></li>
      <li><a href="wwhitegold.php">White Gold</a></li>
	  <li class="divider"></li>
      <li class="dropdown-header">Men's ring</li>
      
	   <li><a href="mdiamond.php">Diamond</a></li>
      <li><a href="mplatinum.php">Platinum</a></li>
      <li><a href="mwhitegold.php">White Gold</a></li>

    </ul>
  </div>

		</li>
		
        <li><div class="dropdown"  style="padding-right:200px; ">
    <!-- <h3 class="btn  dropdown-toggle" type="button" data-toggle="dropdown" style="font-size:19px;">
    <span class="caret"></span></h3> -->
    <ul class="dropdown-menu">
      <li class="dropdown-header">Earing</li>
      <li><a href="ediamond.php">Diamond</a></li>
      <li><a href="epearl.php">Pearl</a></li>
      
      <li class="divider"></li>
      <li class="dropdown-header">Necklace</li>
	   <li><a href="ndiamond.php">Diamond</a></li>
      <li><a href="npearl.php">Pearl</a></li>
	  <li class="divider"></li>
	        <li class="dropdown-header">Bracelets</li>
	   <li><a href="bdiamond.php">Diamond</a></li>
      <li><a href="bpearl.php">Pearl</a></li>
      <li class="divider"></li>
	        <li class="dropdown-header">Bangles</li>
	   <li><a href="gdiamond.php">Diamond</a></li>
      <li><a href="gpearl.php">Pearl</a></li>
      
    </ul>
  </div></li>
		
		
      </ul>
    </div>
	
  </div>
  
</nav>


<div>

  <img src="images/blu1.jpg" alt="Nature" style="width:100%">
  <div class="text-block" style="position: absolute;
    bottom: 220px;
    right:800px;">
	
	<!--h1 style="color:black;" >Introducing-->   <h1 style="color:#191970; font-size:70px; font-family: jokerman; ">  " OMR "</h1>
<h1 style="color:black;font-family: jokerman; ">Scan, Grade, Succeed!</h1>
<h4 style="color:black;">Streamline OMR Evaluation with Precision and Ease</br> Simplify Grading, Maximise Accuracy,</br> Elevate Assessment Processes with our Seamless Solutions</h4>
<a href="index2.php"><button type="button" class="btn btn-lg"  style="background-color:#4062be ; color:white"  >Upload</button></a>
<a href="index1.php"><button type="button" class="btn btn-lg"  style="background-color:#4062be ; color:white"  >Evaluate Here</button></a>
<a href="score.php"><button type="button" class="btn btn-lg" style="background-color:#4062be; color:white"  >View Score</button></a> 
  </div>
</div>







<div style="clear:both;"></div>

	
	
	
           


















</body>
</html>
