<!DOCTYPE html>
<html>
<head>
	<title>account</title>
		 <meta>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

   <?php
   include("connection.php");
   include("session.php");
   ?>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
     <link href="css/font-awesome.css" rel="stylesheet">
   
	  		
		
<style>


.tiny-footer { font-size: 14px; padding: 14px 0px; font-weight: 600; background-color: transparent; border-top: 1px solid #152e3d; color: #888d90; line-height: 1; }


</style>
</head>

	<body class="ma" style="background-color:#f2f2f2">
	<div height="100%">
	 <a href="#"><img src="images/bluemoon.png"  class="img-responsive" class="logo" style="width:250px; height:100px ";
                     alt="Blue Nile&reg;"     title="Blue Nile&reg;"  >
            </a>
			
			<a href="v2.php" class="btn btn-primary btn-sm "style="background-color: 	darkslateblue;float:right; position:absolute;top:50px;right:50px;"> <span placeholder="Back" class="glyphicon glyphicon-arrow-left"></span>   BACK  	</a>
        
		</div>
	
    <!--nav class="navbar navbar-inverse" role="navigation" style="background-color: gainsboro">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->

            <!--div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                 <a class="navbar-brand"  style="font-family:jokerman;color: blue;font-size:35px;text-align: center">Blue Moon</a>
             </div-->  
            
          
            <!-- Collect the nav links, forms, and other content for toggling -->
            <!--div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                  <ul class="nav navbar-nav navbar-right" style="list-style-type:none">
                     <li><a href="webhome1.php"><h4 style="color:red"><span class="glyphicon glyphicon-arrow-left"></span></a></li><h4>

                        
                </ul>
           </div>
        </div>
    </div></nav-->
 <h1 style="font-family:jokerman;text-align:center;color:navy;font-size:40px">Manage Your Account:</h1>
    
    <div class="row" >
    	
    	<div class="col-md-6">
    		  <div class="well" style="background-color:silver;">
                    <h4 class="text-center">VIEW YOUR PROFILE</h4>
                    <hr>
                    <?php
                           
                        {
                            
                          
                            $query=mysqli_query($con,"SELECT * FROM register WHERE reg_id= '$reg_id'") or die(mysqli_error($con));
                            $row=mysqli_fetch_array($query);

                        }

                    ?>
                    <form name="update_form" method="post" action="">
                        <div class="form-group">
                            <label>Name</label>
                            <input type="text" name="user_name" class="form-control" placeholder="user_name " value="<?php echo $row['user_name']; ?>" required>
                        </div>
						 
                       
                       
                        <div class="form-group">
                            <label>email</label>
                            <input type="email" rows="4" name="user_email" class="form-control" placeholder="user_email" value="<?php echo $row['user_email']; ?>">
                           </div>     
                           
                        
                       
                        <div class="form-group">
                            <label>phone  number</label>
                            <input type="text" name="user_phone" class="form-control" placeholder=" mobile number" value="<?php echo $row['user_phone']; ?>" required>
                        </div>
                         <div class="form-group">
                            <label>address </label>
                            <textarea rows="4" name="user_address" class="form-control" placeholder="rest_address"><?php echo $row['user_address']; ?>
                                
                            </textarea>
                        </div>
                       
                         
                       <div class="form-group">
                            <input type="submit" name="update_btn" class="btn btn-warning btn-block" value=" save edited">
                        </div>
                    </form>
                  </div>
              
            </div>
            
     
    	<div class="col-md-6">
            <div class="well" style="background-color:silver;">
                    <h4 class="text-center">CHANGE PASSWORD</h4>
                    <hr>
                    <form name="update_form" method="post" action="manage.php">
                        <div class="form-group">
                            <label>Enter old password</label>
                            <input type="password" name="user_password" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Enter new password</label>
                            <input type="password" name="new_password" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Enter confirm password</label>
                            <input type="password" name="cnew_password" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <input type="submit" name="change" class="btn btn-warning btn-block" value="change">
                        </div>

                    </form>
                </div>
       </div>
            <?php
            if(isset($_POST['change']))
            {
           
             $user_password=$_POST['user_password'];
              $new_password=$_POST['new_password'];
               $cnew_password=$_POST['cnew_password'];
            $sql=mysqli_query($con,"SELECT `user_password` FROM `register` WHERE reg_id='$reg_id'") or die(mysqli_error($con));
            //$old_password=$row["user_password"]; 
            $row=mysqli_fetch_array($sql);
           // $old_password=$row['user_password'];
            if(!$row['user_password'])
            {
                     echo "<script>alert('User does not exist!!!');window.location.href='manage.php';</script>";
            } 
          else  if($user_password==$row['user_password'])
            {
              if($new_password==$cnew_password)
              {
                $sql1=mysqli_query($con,"UPDATE `register` set user_password='$cnew_password' WHERE reg_id=$reg_id") or die(mysqli_error($con)); 
                 echo "<script>alert('Password changed successfully!!!');window.location.href='manage.php';</script>";
              }
              else
                
            echo "<script>alert('Passwords do not match!!!');window.location.href='manage.php';</script>";

            }
            else 
                 echo "<script>alert('Incorrect Password!!!');window.location.href='manage.php';</script>";

}
?>




<?php
    	if (isset($_POST['update_btn'])) 
	{
		
        include("connection.php");


		$user_name=$_POST['user_name'];
		$user_email=$_POST['user_email'];
		$user_phone=$_POST['user_phone'];
		$user_address=$_POST['user_address'];
       
		
		$query=mysqli_query($con,"UPDATE `register` SET 
			`user_name`='$user_name',
				`user_email`='$user_email',
				`user_phone`='$user_phone',
			`user_address`='$user_address' WHERE reg_id='$reg_id'") or die(mysqli_error($con));	
		if (query) 
		{
			
              echo "<script>alert('changes taken into account!!!');window.location.href='manage.php';</script>";

						# code...
		}
		else 
		{
				 echo "<script>alert('something went wrong!!!');window.location.href='manage.php';</script>";

						# code...
		}				
	}


?>
</div>

<!-- <div class="row " style="background-color:#08202e; width:1364px" >
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 text-center ">
                    <div class="tiny-footer">
                        <p>Copyright © All Rights Reserved 2023 | Template Design & Development by <a href="https://easetemplate.com/downloads/bitcoin-cryptocurrency-website-template-amazing-design " target="_blank" class="copyrightlink">EaseTemplate</a></p>
                    </div>
                
            </div>
</div> -->
   <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script> 
</body>
</html>