<?php
if(isset($_POST['login']))
{
include("connection.php");
$email=$_POST['email'];
$password=$_POST['password'];
$query=mysqli_query($con,"SELECT * FROM `register` WHERE user_email='$email' and user_password='$password'") or die(mysqli_error($con));
$row=mysqli_fetch_array($query);

if($row)
{
    session_start();
    $_SESSION['reg_id'] = $row['reg_id'];
    $_SESSION['email']=$email;
    header("location:v2.php?success");
}
else
{
    echo "<script>alert('you have not registered!!');window.location.href='v2login.php';</script>";
}
}

?>
