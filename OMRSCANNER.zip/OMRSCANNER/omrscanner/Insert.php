<?php
    include("session.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Blue moon</title> 
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.css" rel="stylesheet">
    <link href="css/style1.css" rel="stylesheet">
</head>

<body>
<?php
	
	$Id=$_GET['user_id'];
include("connection.php");
 $query=mysqli_query($con,"SELECT *FROM `adminform` WHERE  user_id='$Id'") or die(mysqli_error($con));
            
            while($row=mysqli_fetch_array($query))


{
$Id=$row['user_id'];
$Name=$row['productname'];
$Price=$row['price'];

$Discountprice=$row['discountprice'];
$Category=$row['category'];
$Type=$row['type'];
$Image=$row['image'];
}
	$Total=$Price-$Discountprice;
	$Qty=$_POST['txtQty'];
	$CID=$_SESSION['reg_id'];
	$ODate= date('y/m/d');
	$Net=$Total*$Qty;

	
	
	include("connection.php");
	
	$query1=mysqli_query($con,"INSERT INTO `shopping_cart`(`CartId`, `reg_id`,`user_id`, `ItemName`, `Quantity`, `Price`,`Total`, `OrderDate`) VALUES ('','$CID','$Id','$Name','$Qty','$Price','$Net','$ODate')") or die(mysqli_error($con));

	// Close The Connection
	
	echo '<script type="text/javascript">alert("Item Added To the cart");window.location=\'v2.php\';</script>';
	?>
	<script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>
<script>var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");</script>


</body>
</html>
