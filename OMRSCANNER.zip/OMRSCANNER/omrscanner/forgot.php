<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="G:/BS/css/bootstrap.min.css">
   <link href="css/style1.css" rel="stylesheet">
<style>
body {
    font-family: Arial, Helvetica, sans-serif;
}

* {
    box-sizing: border-box;
}








/* Add padding to containers */
.container {

 width:800px;
 position:relative;
left:300px;
top:100px;

  border-radius: 5px;
 padding: 50px;
 padding-top:0px;   /*padding: 50px;*/
    background-color: silver;
	
}

/* Full-width input fields */
input[type=text], input[type=password] {
    width: 100%;
    padding: 15px;
    margin: 5px 0 22px 0;
    display: inline-block;
    border: none;
    background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
    background-color: #ddd;
    outline: none;
}

/* Overwrite default styles of hr */
hr {
    border: 1px solid #f1f1f1;
    margin-bottom: 25px;
}

/* Set a style for the submit button */
.registerbtn {
    background-color: #4CAF50;
    color: white;
    padding: 16px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
    opacity: 0.9;
}

.registerbtn:hover {
    opacity: 1;
}

/* Add a blue text color to links */
a {
    color: dodgerblue;
	color:blue;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
    background-color: #f1f1f1;
	height:60px;
	width:800px;
	background-color: silver;
    text-align: center;
	position:relative;
left:300px;
top:50px;
padding-top:10px;}
</style>
</head>
<body style="background-color:#f2f2f2">
<div>
<a href="#"><img src="bluemoon.png"  class="img-responsive" class="logo" style="width:280px; float:left; "
                     alt="Blue Nile&reg;"     title="Blue Nile&reg;"  />
				</a>
        </div>
<!--form action="/action_page.php"-->

  <div class="container">
   <form action="" method="post">
    <h1 style=" padding-right:50px; font-family:jokerman; font-size:40px;color:navy;">FORGOT PASSWORD</h1>
    <hr>
<label for="email"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="email" required>

    <label for="name"><b>Name</b></label>
    <input type="text" placeholder="Enter Name" name="name" required>

   

  <label><b> Enter secret word</b></label>
 <input type="password" class="form-control" name="secret"  placeholder="Word that you have entered while signing in." required="">
                     


    <!--label for="psw-repeat"><b>Repeat Password</b></label>
    <input type="password" placeholder="Repeat Password" name="psw-repeat" required-->





    <button type="submit" class="registerbtn" name="submit" value="Submit">Submit</button>
  </div>

  </form> 
   

 

                    <?php
                    include("connection.php");
                    if(isset($_POST['submit']))
                    {
                    	$email=$_POST['email'];
                    	$name=$_POST['name'];
                    	$secret=$_POST['secret'];
                    	$sql=mysqli_query($con,"SELECT  * FROM `register` WHERE user_email='$email' AND user_name='$name' AND user_secret='$secret'") or die(mysqli_error($con)); 
                    	$row=mysqli_fetch_array($sql);
                    	if($sql)
                    	{
                    	
                    	$password=$row['user_password'];
                    	echo 'your password is:';
                    	echo $row['user_password'] ;
                          }
                    	 
                    }
                    ?>
                    	
<!--/form-->

</body>
</html>
