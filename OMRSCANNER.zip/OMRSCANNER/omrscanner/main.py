import cv2
import numpy as np
import utils
import mysql.connector

# MySQL database connection configuration
mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="jewel"
)

# Remaining code from main.py
# ... (your existing code)

widthImg = 700
heightImg = 700
quetions = 30
choises = 4
#####################

# path="1.webp"

path = "teacheruploads/teacherimage.jpg"
path1 = "uploads/image.jpg"
img = cv2.imread(path)
img1 = cv2.imread(path1)

# Resize the image
img = cv2.resize(img, (widthImg, heightImg))

imgContours = img.copy()
imgBiggestContours = img.copy()

img1 = cv2.resize(img1, (widthImg, heightImg))
imgContours1 = img1.copy()
imgBiggestContours1 = img1.copy()
# Preprocessing
# grayscale conversion
imgGray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
imgBlur = cv2.GaussianBlur(imgGray, (5, 5), 1)

imgGray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
imgBlur1 = cv2.GaussianBlur(imgGray1, (5, 5), 1)
##detect the edges using imagrcanny function
imgCanny = cv2.Canny(imgBlur, 10, 50)

imgCanny1 = cv2.Canny(imgBlur, 10, 50)
# FINDING ALL CONTOURs
countours, hierarchy = cv2.findContours(imgCanny, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
cv2.drawContours(imgContours, countours, -1, (0, 255, 0), 10)

countours1, hierarchy1 = cv2.findContours(imgCanny1, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
cv2.drawContours(imgContours1, countours1, -1, (0, 255, 0), 10)

# FIND THE RECT
rectCon = utils.rectcountour(countours)
biggestContour = utils.getCornePoints(rectCon[0])

rectCon1 = utils.rectcountour(countours1)
biggestContour1 = utils.getCornePoints(rectCon1[0])

# print(biggestContour.shape)
gradPoints = utils.getCornePoints(rectCon[1])

gradPoints1 = utils.getCornePoints(rectCon1[1])

# print(biggestContour)


if biggestContour.size != 0 and gradPoints.size != 0:
    cv2.drawContours(imgBiggestContours, biggestContour, -1, (0, 255, 0), 20)
    cv2.drawContours(imgBiggestContours, gradPoints, -1, (255, 0, 0), 20)
    biggestContour = utils.reorder(biggestContour)
    gradPoints = utils.reorder(gradPoints)
    # print(len(biggestContour))
    pt1 = np.float32(biggestContour)
    pt2 = np.float32([[0, 0], [widthImg, 0], [0, heightImg], [widthImg, heightImg]])
    matrix = cv2.getPerspectiveTransform(pt1, pt2)
    imgwarpColored = cv2.warpPerspective(img, matrix, (widthImg, heightImg))

    pt01 = np.float32(gradPoints)
    pt02 = np.float32([[0, 0], [325, 0], [0, 250], [325, 150]])
    matrix0 = cv2.getPerspectiveTransform(pt01, pt02)
    imgGraddisplay = cv2.warpPerspective(img, matrix0, (325, 150))
    # cv2.imshow("Grade",imgGraddisplay)

    # Apply threashhold
    imgWarpGray = cv2.cvtColor(imgwarpColored, cv2.COLOR_BGR2GRAY)
    imgThresh = cv2.threshold(imgWarpGray, 170, 255, cv2.THRESH_BINARY_INV)[1]

    boxes = utils.splitBoxes(imgThresh)
    # cv2.imshow("Test",boxes[2])
    # print(cv2.countNonZero(boxes[0]),cv2.countNonZero(boxes[1]))

    # GETTING PIXELSvalues of each
    mypixelval = np.zeros((quetions, choises))
    countC = 0
    countR = 0
    for image in boxes:
        totalPixels = cv2.countNonZero(image)
        mypixelval[countR][countC] = totalPixels
        countC += 1
        if (countC == choises): countR += 1;countC = 0

    # Add this code to process the last row if it's not already processed
    if countR < quetions:
        for x in range(countR, quetions):
            arr = mypixelval[x]
            myIndexval = np.where(arr == np.amax(arr))
            print(myIndexval[0])

    print(mypixelval)

    myIndex = []
    for x in range(0, quetions):
        arr = mypixelval[x]
        myIndexval = np.where(arr == np.amax(arr))
        print(myIndexval[0])

if biggestContour1.size != 0 and gradPoints1.size != 0:
    cv2.drawContours(imgBiggestContours1, biggestContour1, -1, (0, 255, 0), 20)
    cv2.drawContours(imgBiggestContours1, gradPoints1, -1, (255, 0, 0), 20)
    biggestContour1 = utils.reorder(biggestContour1)
    gradPoints1 = utils.reorder(gradPoints1)
    # print(len(biggestContour))
    pt3 = np.float32(biggestContour1)
    pt4 = np.float32([[0, 0], [widthImg, 0], [0, heightImg], [widthImg, heightImg]])
    matrix1 = cv2.getPerspectiveTransform(pt3, pt4)
    imgwarpColored1 = cv2.warpPerspective(img1, matrix1, (widthImg, heightImg))

    pt03 = np.float32(gradPoints1)
    pt04 = np.float32([[0, 0], [325, 0], [0, 250], [325, 150]])
    matrix2 = cv2.getPerspectiveTransform(pt03, pt04)
    imgGraddisplay1 = cv2.warpPerspective(img1, matrix2, (325, 150))
    # cv2.imshow("Grade",imgGraddisplay)

    # Apply threashhold
    imgWarpGray1 = cv2.cvtColor(imgwarpColored1, cv2.COLOR_BGR2GRAY)
    imgThresh1 = cv2.threshold(imgWarpGray1, 170, 255, cv2.THRESH_BINARY_INV)[1]

    boxes1 = utils.splitBoxes(imgThresh1)
    # cv2.imshow("Test",boxes[2])
    # print(cv2.countNonZero(boxes[0]),cv2.countNonZero(boxes[1]))

# GETTING PIXELS values of each
mypixelval1 = np.zeros((quetions, choises))
countC1 = 0
countR1 = 0
for image in boxes1:
    totalPixels1 = cv2.countNonZero(image)
    if totalPixels1 <= 1535:
        totalPixels1 = 0
    # Case 1: If more than one bubble is marked in a row, marks for that row should be zero
    if totalPixels1 > 1535 * 0.9:  # If more than 90% marked, consider it fully marked
        mypixelval1[countR1][countC1] = 0  # Set marks as zero for this row
    else:
        mypixelval1[countR1][countC1] = totalPixels1
    # Case 2: For single bubbled options, only consider full marks when the bubble is 90% marked
    if totalPixels1 > 1535 * 0.9:  # If more than 90% marked, consider it fully marked
        mypixelval1[countR1][countC1] = 1535  # Consider it a full mark
    else:
        mypixelval1[countR1][countC1] = 0  # Consider it zero marks
    countC1 += 1
    if (countC1 == choises): countR1 += 1;countC1 = 0

print(mypixelval1)

# Calculate marks
marks = 0
for x in range(quetions):
    if np.count_nonzero(mypixelval1[x]) == 1:  # If only one bubble is marked
        if np.argmax(mypixelval1[x]) == np.argmax(mypixelval[x]):  # If the marked bubble is correct
            marks += 1
    print(f"Question {x + 1}: myIndexval = {np.argmax(mypixelval[x])}, myIndexval1 = {np.argmax(mypixelval1[x])},count={mypixelval1[x].sum()},marks={marks}")

print("Total marks:", marks)

# Insert marks into the database
mycursor = mydb.cursor()
sql = "INSERT INTO marks (value) VALUES (%s)"
val = (marks,)
mycursor.execute(sql, val)
mydb.commit()

print("Marks value inserted successfully")

# Close the database connection
mydb.close()
